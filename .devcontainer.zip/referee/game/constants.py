# COMP30024 Artificial Intelligence, Semester 1 2025
# Project Part B: Game Playing Agent

GAME_NAME       = "Freckers"
NUM_PLAYERS     = 2

BOARD_N         = 8
MAX_TURNS       = 150
